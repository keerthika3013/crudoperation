package com.example.office;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfficeApplicationTests {

	@Test
	void contextLoads() {
	}

}
